import json,pathlib,hashlib,subprocess,copy,socket,datetime,sys,re
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(r'C:/Users/Dylan/Documents/Data Science/political_fingerprint/.w/ib');out=pathlib.Path(r'C:/Users/Dylan/AppData/Local/Temp/immigration_independent_ed7f5a3c_20261017');base='docs/editorial/shared_candidates/house_119_immigration_20260916/'
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
def read(p):return json.loads((root/p).read_text(encoding='utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def seal(v,k):return digest({a:b for a,b in v.items() if a!=k})
def at(v,p):
 for k in p.split('/')[1:]:v=v[int(k)] if isinstance(v,list) else v[k.replace('~1','/').replace('~0','~')]
 return v
def walk(v,p=''):
 yield p,v
 if isinstance(v,dict):
  for k,x in v.items():yield from walk(x,p+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from walk(x,p+'/'+str(i))
def diff(a,b,p=''):
 if type(a)!=type(b):return [p]
 if isinstance(a,dict):
  return [z for k in a.keys()|b.keys() for z in ([p+'/'+k] if k not in a or k not in b else diff(a[k],b[k],p+'/'+k))]
 if isinstance(a,list):
  if len(a)!=len(b):return [p+f' [length {len(a)}->{len(b)}]']
  return [z for i,(x,y) in enumerate(zip(a,b)) for z in diff(x,y,p+'/'+str(i))]
 return [] if a==b else [p]
R={'started_utc':'2026-10-17T04:59:20+00:00','actual_host':socket.gethostname(),'root':str(root),'head':git('rev-parse','HEAD').decode().strip(),'checks':{},'files':{}}
assert R['head']=='ed7f5a3c8258edc510b652cf65461c4b8764fb64'
expected={'authoring.json':'bb508e73abd30cb1e2ce5b739e9f76ff2a83386c','generated/shared_action_core.json':'86a21dd814fc12884472a2dae033f5e960311e7d','generated/readable_candidates.json':'d18f4818299c9abc7c63a0859314ab3f5e6c92d6','closure_audit_correction_checkpoint261.json':'2dbdc876e6320bf5b627eefa4cdcc32d317aeebb'}
for f,obj in expected.items():
 p=base+f;b=(root/p).read_bytes();stored=git('cat-file','blob',obj);tree=git('rev-parse','HEAD:'+p).decode().strip()
 assert tree==obj;assert json.loads(b)==json.loads(stored);assert git('hash-object','--path='+p,str(root/p)).decode().strip()==obj
 R['files'][p]={'supplied_git_blob':obj,'head_tree_blob':tree,'actual_bytes_sha256':sha(b),'actual_bytes_length':len(b),'blob_bytes_sha256':sha(stored),'actual_equals_blob':b==stored}
q=read(base+'closure_audit_correction_checkpoint261.json');parent=q['base_head'];R['parent']=parent;assert git('rev-parse','HEAD^').decode().strip()==parent
A=read(base+'authoring.json');C=read(base+'generated/shared_action_core.json');PA=json.loads(git('show',parent+':'+base+'authoring.json'));PC=json.loads(git('show',parent+':'+base+'generated/shared_action_core.json'));aa={x['action_id']:x for x in A['actions']};cc={x['action_id']:x for x in C['actions']};pa={x['action_id']:x for x in PA['actions']};pc={x['action_id']:x for x in PC['actions']}
assert seal(q,'receipt_sha256')==q['receipt_sha256'];assert seal(C,'corpus_sha256')!=C['corpus_sha256'];assert digest(C['actions'])==C['corpus_sha256'];assert all(seal(c,'action_core_sha256')==c['action_core_sha256'] for c in C['actions'])
fixes=[]
for aid,old in q['prior_authoring'].items():
 assert old==pa[aid];assert q['prior_cores'][aid]==pc[aid]
 exp=copy.deepcopy(old)
 for f in q['fixes']:
  if f['action_id']!=aid:continue
  if f['field']=='meaning':
   assert exp['meaning'].count(f['before'])==1
   assert exp['meaning'].index(f['before'])==f['offset']
   exp['meaning']=exp['meaning'].replace(f['before'],f['after'],1)
  else:assert exp[f['field']][f['index']]==f['before'];exp[f['field']][f['index']]=f['after']
  fixes.append(f)
 if aid==q['added_claim_binding']['action_id']:exp['claim_source_map'].append(q['added_claim_binding']['binding'])
 assert exp==aa[aid];assert digest(exp)==q['current_authoring_sha256'][aid]
R['checks']['exact_six_authoring_replacements_plus_one_binding']={'passed':True,'fixes':fixes}
assert len(fixes)==6
for aid in aa:
 assert digest(pa[aid])==q['prior_all_authoring_sha256'][aid];assert pc[aid]['action_core_sha256']==q['prior_all_core_sha256'][aid]
 if aid not in q['actions']:assert aa[aid]==pa[aid] and cc[aid]==pc[aid]
R['checks']['other_84_authoring_and_core_rows_exact']=True
active={p:read(p) for p in q['active_copy_files']};active_before={p:json.loads(git('show',parent+':'+p)) for p in q['active_copy_files']};strings=[]
for r in q['active_string_repairs']:
 v=at(active[r['path']],r['pointer']);old=at(active_before[r['path']],r['pointer']);assert digest(v)==r['after_sha256'];assert digest(old)==r['before_sha256'];assert not any(f['before'] in v for f in fixes);strings.append(r)
R['checks']['all_38_registered_active_string_repairs']=strings
R['checks']['independently_discovered_fullmeaning_copies']={}
for aid in q['actions']:
 m=aa[aid]['meaning'];old=pa[aid]['meaning'];copies=[]
 for path,d in active.items():
  for ptr,v in walk(d):
   if isinstance(v,str) and v==m:copies.append({'path':path,'pointer':ptr,'chars':len(v),'sha256':digest(v)})
  assert not any(isinstance(v,str) and v==old for ptr,v in walk(d))
 assert len(copies)==8,(aid,len(copies));R['checks']['independently_discovered_fullmeaning_copies'][aid]=copies
for r in q['active_claimmap_repairs']:assert at(active[r['path']],r['pointer'])==pa['house:119:1:70']['claim_source_map']+[q['added_claim_binding']['binding']]
R['checks']['four_11205_claimmap_copies']=q['active_claimmap_repairs']
sources={x['source_id']:x for x in read(base+'sources.json')['sources']};eh=sources['govinfo:hr1968eh'];binding=q['added_claim_binding']['binding'];assert len(eh['text'])==109266;assert eh['text'][82570:82807]==binding['passage'];assert seal(eh,'governed_bytes_sha256')==eh['governed_bytes_sha256'];assert {k:eh[k] for k in q['added_claim_binding']['source_identity']}==q['added_claim_binding']['source_identity']
R['checks']['11205_exact_retained_text']={'source_id':eh['source_id'],'extent':[82570,82807,109266],'passage':binding['passage'],'source_seal':eh['governed_bytes_sha256']}
for p in ['generated/compiled_ir.json','generated/shared_issue_mapping.json','sources.json','research_capture_manifest.json','universe_proposal.json']:
 b=(root/(base+p)).read_bytes();old=git('show',parent+':'+base+p);assert json.loads(b)==json.loads(old);R['checks'][p+'_parent_exact']={'bytes_equal':b==old,'json_equal':True,'actual_sha256':sha(b)}
pro=read(base+'generated/member_projections.json');oldpro=json.loads(git('show',parent+':'+base+'generated/member_projections.json'));assert oldpro==q['prior_member_projections'];prodiff=diff(oldpro,pro);assert len(prodiff)==8 and sum(x.endswith('/action_core_sha256') for x in prodiff)==6 and sum(x.endswith('/projection_sha256') for x in prodiff)==2;assert all(seal(m,'projection_sha256')==m['projection_sha256'] for m in pro)
R['checks']['174_member_projection_conservation']={'passed':True,'only_changes':prodiff,'count':sum(len(m['actions']) for m in pro)}
ir=read(base+'generated/compiled_ir.json');assert {m['member_id']:digest(m['proposition_graph']) for m in ir['members']}==q['prior_proposition_graph_sha256'];R['checks']['145_propositions_entire_graph_conservation']=q['prior_proposition_graph_sha256']
R['checks']['core_diff_paths']=diff(PC,C);R['checks']['all_317_protected_json_checks']={}
for p,h in q['protected_json_sha256'].items():
 v=read(p);assert digest(v)==h,p
 old=json.loads(git('show',parent+':'+p));assert old==v,p
 R['checks']['all_317_protected_json_checks'][p]=h
R['checks']['prior_file_preimages']={}
for p,h in q['prior_file_sha256'].items():
 b=(root/'.tmp/checkpoint261_before'/p).read_bytes();assert sha(b)==h,p;old=git('show',parent+':'+p)
 if p.endswith('.json'):assert json.loads(b)==json.loads(old)
 else:assert b.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n')
 R['checks']['prior_file_preimages'][p]={'sha256':h,'parent_equivalent':True}
q260=read(base+'shared_member_neutrality_correction_checkpoint260.json');assert seal(q260,'receipt_sha256')==q260['receipt_sha256'];proposal=read(q260['successor_proposal_ref']);assert digest(proposal['actions'])==proposal['corpus_sha256'];prov={r['action_id']:r for r in proposal['actions']}
R['checks']['checkpoint260_complete_copy_retention']={}
for aid in q260['actions']:
 exp=copy.deepcopy(q260['prior_authoring'][aid]);f=next(x for x in q260['fixes'] if x['action_id']==aid);assert exp['meaning'].count(f['before'])==1;exp['meaning']=exp['meaning'].replace(f['before'],f['after'],1)
 assert aa[aid]['meaning']==exp['meaning'];assert cc[aid]==prov[aid];assert seal(cc[aid],'action_core_sha256')==cc[aid]['action_core_sha256'];assert aa[aid]==pa[aid]
 copies=[]
 for path,d in active.items():
  for ptr,v in walk(d):
   if isinstance(v,str) and v==aa[aid]['meaning']:copies.append({'path':path,'pointer':ptr,'chars':len(v)})
 assert len(copies)==8,(aid,len(copies))
 assert all(not re.search(r'Foushee|Massie|either member|both members',str(v),re.I) for k,v in aa[aid].items() if k in ['meaning','limitations','short_description','compact_description','choice_meanings'])
 for b in aa[aid]['claim_source_map']:
  assert b['passage'] in sources[b['source_id']]['text'],(aid,b['source_id'],b['locator'])
 R['checks']['checkpoint260_complete_copy_retention'][aid]={'copies':copies,'successor_proposal_ref':q260['successor_proposal_ref'],'complete_meaning_sha256':digest(aa[aid]['meaning']),'source_bindings':len(aa[aid]['claim_source_map']),'all_binding_passages_literal':True,'old_fragment_absent':f['before'] not in aa[aid]['meaning'],'new_fragment_once':aa[aid]['meaning'].count(f['after'])==1}
R['checks']['candidate_only_flags']={'review_state':A['review_state'],'core_authority':C['authoritative_for_new_editorial_work'],'readable_production_eligible':active[base+'generated/readable_candidates.json']['production_eligible']}
uni=read(base+'universe_proposal.json');R['checks']['retained_holds']=uni['unresolved_action_ids'];R['checks']['partial_components']=uni['accounting']['partial_component_reviews']
R['tracked_status']=git('status','--porcelain','--untracked-files=no').decode();assert not R['tracked_status']
(out/'mechanical_review.json').write_text(json.dumps(R,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('PASS',len(R['checks']),'check groups; written',out/'mechanical_review.json');print('FILES',R['files']);print('COPIES260',R['checks']['checkpoint260_complete_copy_retention'])



