import json,pathlib,hashlib,subprocess,datetime,socket,re
root=pathlib.Path(r'C:/Users/Dylan/Documents/Data Science/political_fingerprint/.w/ib');out=pathlib.Path(r'C:/Users/Dylan/AppData/Local/Temp/immigration_independent_ed7f5a3c_20261017');base='docs/editorial/shared_candidates/house_119_immigration_20260916/'
def read(p):return json.loads((root/p).read_text(encoding='utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def seal(v,k):return digest({a:b for a,b in v.items() if a!=k})
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
R={'head':git('rev-parse','HEAD').decode().strip(),'scope':'Supplemental finite source/meaning verification; no complete current-law, full-package or individual-application certification.'};q=read(base+'closure_audit_correction_checkpoint261.json');A=read(base+'authoring.json');aa={x['action_id']:x for x in A['actions']};C=read(base+'generated/shared_action_core.json');cc={x['action_id']:x for x in C['actions']};sources={x['source_id']:x for x in read(base+'sources.json')['sources']}
R['line_endings']={}
for f in ['authoring.json','generated/shared_action_core.json','generated/readable_candidates.json','closure_audit_correction_checkpoint261.json']:
 b=(root/(base+f)).read_bytes();blob=git('show','HEAD:'+base+f);assert b.replace(b'\r\n',b'\n')==blob
 R['line_endings'][f]={'difference_only_CRLF_to_LF':True,'actual_sha256':sha(b),'blob_sha256':sha(blob)}
R['protected_actual_bytes']={'checked':len(q['protected_file_sha256']),'mismatches':[]}
for p,h in q['protected_file_sha256'].items():
 actual=sha((root/p).read_bytes())
 if actual!=h:R['protected_actual_bytes']['mismatches'].append({'path':p,'expected':h,'actual':actual})
assert not R['protected_actual_bytes']['mismatches']
R['action_source_bindings']={}
for aid in ['house:119:2:5','house:119:2:7','house:119:1:199']:
 action=aa[aid];bindings=[]
 for i,b in enumerate(action['claim_source_map']):
  src=sources[b['source_id']];text=src['text'];assert b['passage'] in text;assert seal(src,'governed_bytes_sha256')==src['governed_bytes_sha256']
  start=text.index(b['passage']);bindings.append({'binding_index':i,'source_id':src['source_id'],'start':start,'end':start+len(b['passage']),'total':len(text),'passage_sha256':digest(b['passage']),'governed_bytes_sha256':src['governed_bytes_sha256'],'locator':b['locator']})
 R['action_source_bindings'][aid]={'complete_meaning_chars':len(action['meaning']),'complete_meaning_sha256':digest(action['meaning']),'complete_authoring_sha256':digest(action),'core_seal':cc[aid]['action_core_sha256'],'bindings':bindings,'limits_count':len(action['limitations']),'all_literal_passages_and_source_seals':True}
R['personally_read_source_extents']={}
for sid in ['immigration:divisionA-roll5-own-record214','immigration:hr6938-roll7-whole-choice217','govinfo:hres977eh','govinfo:34usc20703-2024-child-deterrence-block-grants','govinfo:34usc20705-2024-state-local-law-enforcement-grants','govinfo:pl109-164-sec203-historical-juvenile-pilot','govinfo:pl109-164-sec204-historical-state-local-grants','govinfo:pl113-4-sec1242-state-local-grant-amendments','govinfo:5usc2102-2024-fin237','govinfo:5usc2103-2024-fin237','govinfo:5cfr7-3-2025-fin237','govinfo:5cfr338-101-2025-fin237','govinfo:5cfr316-601-2025-fin237']:
 s=sources[sid];R['personally_read_source_extents'][sid]={'extent':[0,len(s['text']),len(s['text'])],'text_sha256':digest(s['text']),'governed_bytes_sha256':s['governed_bytes_sha256']}
R['personally_read_199_binding_indices']=[30,31,32,38,40,41,42,44,45,46]
assert R['action_source_bindings']['house:119:1:199']['bindings'][44]['start']==244481
for stem,sid in [('34usc20703','govinfo:34usc20703-2024-child-deterrence-block-grants'),('34usc20705','govinfo:34usc20705-2024-state-local-law-enforcement-grants')]:
 n='103' if stem.endswith('3') else '104';raw=(root/f'.tmp/{stem}-original{n}.html').read_bytes();assert sha(raw)==sources[sid]['raw_sha256']
R['registered_PL117328']={};registered=next(x for x in read(base+'research_capture_manifest.json')['sources'] if x['source_id']=='govinfo:pl117-328-complete-original');assert registered==q['status_evidence']['registered_full_original'];raw=(root/'.tmp/pl117328-original112.html').read_bytes();text=(root/'.tmp/pl117328-full112.txt').read_text(encoding='utf-8');assert sha(raw)==registered['raw_sha256'];assert digest(text)==registered['text_sha256'];assert len(text)==registered['text_length'];pool=read('.tmp/ib_primary_captures.json');full=next(x for x in pool['sources'] if x['source_id']==registered['source_id']);assert full['text']==text;assert seal(full,'governed_bytes_sha256')==registered['governed_bytes_sha256']==full['governed_bytes_sha256']
R['registered_PL117328']={'manifest':registered,'actual_raw_bytes':len(raw),'actual_raw_sha256':sha(raw),'actual_text_utf8_sha256':sha(text.encode()),'canonical_json_text_sha256':digest(text),'full_governed_source_seal_verified':True,'reading_limit':'Registration and retained source identity personally verified; no whole-law substantive reading claimed.'}
q237=read(base+'financial_employment_qualification_checkpoint237.json');assert q237['receipt_sha256']==seal(q237,'receipt_sha256');ref=aa['house:119:1:199']['shared_core_reuse'];provider=read(ref['artifact_ref']);c237=next(x for x in provider['actions'] if x['action_id']=='house:119:1:199');assert c237==cc['house:119:1:199'];assert c237['candidate_exact_action_meaning']==aa['house:119:1:199']['meaning'];assert c237['action_core_sha256']==q237['new_core_sha256']['house:119:1:199']
for imported in q237['source_imports']:
 if imported['source_id'].endswith('-fin237') and imported['source_id'] in {b['source_id'] for b in aa['house:119:1:199']['claim_source_map']}:
  assert sha((root/imported['source_artifact_ref']).read_bytes())==imported['raw_sha256']
summary=read('docs/review_packets/immigration_checkpoint238_conservation_validation.json');R['prior_review_199_attribution']={'retained_summary_path':'docs/review_packets/immigration_checkpoint238_conservation_validation.json#/HRA_precision_receipt/independent237_review_scope','retained_summary':summary['HRA_precision_receipt']['independent237_review_scope'],'source_note':'This is a retained summary, not the full independent report. It reports 76 financial/stablecoin passages across a combined review, not an unambiguous whole-current-1:199 clearance.','owner_material_reading':q237['material_reading'],'current_core_exactly_equals_237_provider':True,'fresh_scope_this_review':'Complete current 7860-character meaning and all9 limits; complete bound outer410(a)-(h), dated2102/2103 and7.3/338.101/316.601, July version/adopted106(c),405(a)-(b),409 and self-custody105(c)/512GENIUS22 extents, literal-source map/seal checks for47bindings. This supplies an explicit current action-level bounded review without attributing the whole prior combined76passages to199.'}
# Complete current meaning copies for199; do not treat audit summary as independent approval.
active={p:read(p) for p in q['active_copy_files']}
def walk(v,p=''):
 yield p,v
 if isinstance(v,dict):
  for k,x in v.items():yield from walk(x,p+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from walk(x,p+'/'+str(i))
R['199_current_fullmeaning_copies']=[{'path':p,'pointer':ptr} for p,d in active.items() for ptr,v in walk(d) if isinstance(v,str) and v==aa['house:119:1:199']['meaning']];assert len(R['199_current_fullmeaning_copies'])==7,len(R['199_current_fullmeaning_copies'])
R['typed_hr1048_hold_witnesses']=[]
for ptr,v in walk(read(base+'generated/compiled_ir.json')):
 if isinstance(v,dict) and any(x in str(v.get(k,'')) for k in ['action_id','action_ids','evidence_action_ids'] for x in ['house:119:1:79','house:119:1:83']):
  if any(x in str(v).lower() for x in ['hold','blocked','uncertain']):R['typed_hr1048_hold_witnesses'].append({'pointer':ptr,'keys':list(v)})
R['final_tracked_status']=git('status','--porcelain','--untracked-files=no').decode();assert not R['final_tracked_status'];assert git('rev-parse','HEAD').decode().strip()==R['head'];R['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'source_scope_review.json').write_text(json.dumps(R,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('PASS supplemental source scope; 57+111+47literal source bindings; 316actual protected files; registered PL117328 raw/text/governed seal; 199 current copies',len(R['199_current_fullmeaning_copies']))

